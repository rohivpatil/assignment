import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-postview',
  templateUrl: './postview.component.html',
  styleUrls: ['./postview.component.css']
})
export class PostviewComponent implements OnInit {

  constructor(private api:ApiService,
    private router:Router,
    private active_router:ActivatedRoute) { }

   view:any;

  ngOnInit(): void {
    this.userdata(this.active_router.snapshot.params.id);
  }
  userdata(id:number){
    this.api.api_data(id).subscribe((res)=>{
      this.view=res;
    });

}
}
