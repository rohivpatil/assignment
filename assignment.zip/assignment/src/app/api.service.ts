import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  database:any;

  constructor(private http: HttpClient) { }
  id_data(){
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
  }
  get_data(){
    return this.http.get("https://jsonplaceholder.typicode.com/posts");
  }
  api_data(id:number){
    return this.http.get("https://jsonplaceholder.typicode.com/posts?id="+id);
  }
}
