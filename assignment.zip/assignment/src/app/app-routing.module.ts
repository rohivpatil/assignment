import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { PostviewComponent } from './postview/postview.component';
import { TableComponent } from './table/table.component';

const routes: Routes = [
  {path:"",component:TableComponent},
  {path:"header",component:HeaderComponent},
  {path:"table",component:TableComponent},
  {path:"postview/:id", component:PostviewComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
