import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {

  constructor(private api:ApiService, private router:Router, private active_router:ActivatedRoute) { }
  post:any;

  send_id(id:number){
    this.router.navigate(['/postview', id]);
  }
  ngOnInit(): void {
    this.post=this.api.database;
    this.api.id_data().subscribe((res)=>{
      this.post=res;
    });
    
 
  }

}
